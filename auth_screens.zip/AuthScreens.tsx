// AuthScreens.tsx
import React, { useState } from "react";

const AuthScreens = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "student" });

  const toggle = () => setIsLogin(!isLogin);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const endpoint = isLogin ? "/api/auth/login" : "/api/auth/register";
    fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    })
      .then(res => res.json())
      .then(data => {
        if (data.accessToken) {
          localStorage.setItem("token", data.accessToken);
          alert("Logged in successfully");
        } else {
          alert(data.message || "Done");
        }
      });
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#F4F4F4] dark:bg-[#1E1E1E]">
      <div className="w-full max-w-md p-6 bg-white dark:bg-[#1E1E1E] shadow rounded">
        <h2 className="text-2xl font-bold text-[#2E7D32] mb-4 text-center">
          {isLogin ? "Login" : "Register"} to EduSphere
        </h2>
        <form className="space-y-4" onSubmit={handleSubmit}>
          {!isLogin && (
            <input
              name="name"
              type="text"
              placeholder="Full Name"
              className="w-full p-2 border rounded"
              onChange={handleChange}
              required
            />
          )}
          <input
            name="email"
            type="email"
            placeholder="Email"
            className="w-full p-2 border rounded"
            onChange={handleChange}
            required
          />
          <input
            name="password"
            type="password"
            placeholder="Password"
            className="w-full p-2 border rounded"
            onChange={handleChange}
            required
          />
          {!isLogin && (
            <select
              name="role"
              className="w-full p-2 border rounded"
              onChange={handleChange}
              value={form.role}
            >
              <option value="student">Student</option>
              <option value="tutor">Tutor</option>
            </select>
          )}
          <button type="submit" className="w-full py-2 bg-[#2E7D32] text-white rounded">
            {isLogin ? "Login" : "Register"}
          </button>
        </form>
        <p className="text-center text-sm text-gray-600 dark:text-gray-300 mt-4">
          {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
          <button onClick={toggle} className="text-[#FFD700] underline">
            {isLogin ? "Register" : "Login"} here
          </button>
        </p>
      </div>
    </div>
  );
};

export default AuthScreens;
