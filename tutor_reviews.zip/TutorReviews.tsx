// TutorReviews.tsx
import React, { useEffect, useState } from "react";

const TutorReviews = ({ tutorId }: { tutorId: string }) => {
  const [reviews, setReviews] = useState<any[]>([]);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  const studentId = "student123"; // Replace with actual user ID from auth context

  useEffect(() => {
    fetch(`/api/reviews/tutor/${tutorId}`)
      .then(res => res.json())
      .then(setReviews);
  }, [tutorId]);

  const submitReview = () => {
    fetch("/api/reviews/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tutorId, studentId, rating, comment }),
    })
      .then(res => res.json())
      .then(newReview => setReviews([newReview, ...reviews]));
  };

  return (
    <div className="p-4 bg-white dark:bg-[#1E1E1E] rounded shadow">
      <h3 className="text-xl font-bold mb-4 text-[#2E7D32]">Tutor Reviews</h3>

      <div className="mb-6">
        <h4 className="font-semibold mb-1">Leave a Review</h4>
        <input
          type="number"
          min={1}
          max={5}
          value={rating}
          onChange={e => setRating(Number(e.target.value))}
          className="border p-2 mr-2 w-20"
        />
        <input
          type="text"
          value={comment}
          onChange={e => setComment(e.target.value)}
          placeholder="Your feedback"
          className="border p-2 w-1/2 mr-2"
        />
        <button onClick={submitReview} className="px-4 py-2 bg-[#2E7D32] text-white rounded">
          Submit
        </button>
      </div>

      <div className="space-y-2">
        {reviews.map((r, i) => (
          <div key={i} className="border-t pt-2">
            <p className="font-medium">⭐ {r.rating}/5</p>
            <p>{r.comment}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TutorReviews;
