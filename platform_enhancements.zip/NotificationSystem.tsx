// NotificationSystem.tsx
import React, { useEffect, useState } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000");

const NotificationSystem = ({ userId }: { userId: string }) => {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unread, setUnread] = useState<number>(0);

  useEffect(() => {
    fetch(`/api/notifications/${userId}`)
      .then(res => res.json())
      .then(data => {
        setNotifications(data);
        setUnread(data.filter((n: any) => !n.read).length);
      });

    socket.emit("join_notifications", userId);

    socket.on("new_notification", (notif: any) => {
      setNotifications(prev => [notif, ...prev]);
      setUnread(prev => prev + 1);
    });

    return () => socket.disconnect();
  }, [userId]);

  const markAllRead = () => {
    fetch(`/api/notifications/mark-read/${userId}`, { method: "POST" });
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    setUnread(0);
  };

  return (
    <div className="relative">
      <button onClick={markAllRead} className="relative">
        <span className="text-lg">🔔</span>
        {unread > 0 && (
          <span className="absolute top-0 right-0 bg-red-600 text-white text-xs rounded-full px-1">
            {unread}
          </span>
        )}
      </button>
      <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-[#1E1E1E] border rounded shadow z-10">
        {notifications.slice(0, 5).map((n, idx) => (
          <div key={idx} className="px-3 py-2 border-b border-gray-200 dark:border-gray-700">
            {n.message}
          </div>
        ))}
        {notifications.length === 0 && <div className="px-3 py-2 text-sm">No notifications</div>}
      </div>
    </div>
  );
};

export default NotificationSystem;
