// ScheduleCalendar.tsx
import React, { useEffect, useState } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";

const localizer = momentLocalizer(moment);

const ScheduleCalendar = ({ userId }: { userId: string }) => {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetch(`/api/classes/booked/${userId}`)
      .then(res => res.json())
      .then(data => {
        const formatted = data.map((cls: any) => ({
          title: `${cls.subject} with ${cls.tutor}`,
          start: new Date(cls.time),
          end: new Date(new Date(cls.time).getTime() + 60 * 60 * 1000),
        }));
        setEvents(formatted);
      });
  }, [userId]);

  return (
    <div className="p-4 bg-white dark:bg-[#1E1E1E] rounded shadow h-[80vh]">
      <h2 className="text-xl font-bold mb-4 text-[#2E7D32]">My Schedule</h2>
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        style={{ height: "100%" }}
      />
    </div>
  );
};

export default ScheduleCalendar;
