const express = require("express");
const router = express.Router();
const Withdrawal = require("../models/Withdrawal");

router.post("/withdraw", async (req, res) => {
  const { tutorId, amount, method, accountDetails } = req.body;
  await Withdrawal.create({
    tutorId,
    amount,
    method,
    accountDetails,
    status: "pending",
    createdAt: new Date()
  });
  res.sendStatus(201);
});

router.get("/earnings/:tutorId", async (req, res) => {
  // Simulated total for simplicity
  res.json({ total: 1200 });
});

router.get("/withdrawals/:tutorId", async (req, res) => {
  const withdrawals = await Withdrawal.find({ tutorId: req.params.tutorId });
  res.json(withdrawals);
});

module.exports = router;
