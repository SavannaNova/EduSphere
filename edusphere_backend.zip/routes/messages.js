const express = require("express");
const router = express.Router();
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");

// Create or find conversation between two users
router.post("/start", async (req, res) => {
  const { user1, user2 } = req.body;
  let convo = await Conversation.findOne({ users: { $all: [user1, user2] } });
  if (!convo) convo = await Conversation.create({ users: [user1, user2] });
  res.json(convo);
});

// Send message
router.post("/send", async (req, res) => {
  const { conversationId, senderId, content } = req.body;
  const message = await Message.create({ conversationId, senderId, content });
  res.status(201).json(message);
});

// Get all messages in a conversation
router.get("/:conversationId", async (req, res) => {
  const messages = await Message.find({ conversationId: req.params.conversationId }).sort({ timestamp: 1 });
  res.json(messages);
});

// List conversations for a user
router.get("/conversations/:userId", async (req, res) => {
  const convos = await Conversation.find({ users: req.params.userId });
  res.json(convos);
});

module.exports = router;
