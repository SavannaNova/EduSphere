const express = require("express");
const router = express.Router();
const Class = require("../models/Class");

router.get("/booked/:studentId", async (req, res) => {
  const classes = await Class.find({ studentId: req.params.studentId });
  res.json(classes);
});

module.exports = router;
