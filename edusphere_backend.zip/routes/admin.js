const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Report = require("../models/Report");

router.get("/stats", async (req, res) => {
  const totalUsers = await User.countDocuments();
  const totalEarnings = 23456; // mock
  const activeSessions = 14; // mock
  res.json({ totalUsers, totalEarnings, activeSessions });
});

router.get("/users", async (req, res) => {
  const users = await User.find();
  res.json(users);
});

router.post("/verify/:userId", async (req, res) => {
  await User.findByIdAndUpdate(req.params.userId, { verified: true });
  res.sendStatus(200);
});

router.post("/users/ban/:userId", async (req, res) => {
  await User.findByIdAndDelete(req.params.userId);
  res.sendStatus(200);
});

router.get("/reports", async (req, res) => {
  const reports = await Report.find();
  res.json(reports);
});

router.post("/reports/resolve/:id", async (req, res) => {
  await Report.findByIdAndDelete(req.params.id);
  res.sendStatus(200);
});

module.exports = router;
