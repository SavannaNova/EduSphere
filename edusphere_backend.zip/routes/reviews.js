const express = require("express");
const router = express.Router();
const Review = require("../models/Review");

router.post("/submit", async (req, res) => {
  const review = await Review.create(req.body);
  res.status(201).json(review);
});

router.get("/tutor/:tutorId", async (req, res) => {
  const reviews = await Review.find({ tutorId: req.params.tutorId });
  res.json(reviews);
});

module.exports = router;
