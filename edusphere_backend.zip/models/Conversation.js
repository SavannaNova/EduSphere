const mongoose = require("mongoose");

const conversationSchema = new mongoose.Schema({
  users: [String], // [studentId, tutorId]
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Conversation", conversationSchema);
