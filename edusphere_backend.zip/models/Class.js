const mongoose = require("mongoose");

const classSchema = new mongoose.Schema({
  studentId: String,
  tutor: String,
  subject: String,
  time: Date,
  status: String
});

module.exports = mongoose.model("Class", classSchema);
