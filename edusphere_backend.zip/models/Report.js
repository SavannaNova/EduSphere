const mongoose = require("mongoose");

const reportSchema = new mongoose.Schema({
  reason: String,
  reportedBy: String,
  target: String,
  targetId: String
});

module.exports = mongoose.model("Report", reportSchema);
