const request = require("supertest");
const app = require("../server");
const mongoose = require("mongoose");
const Message = require("../models/Message");
const Conversation = require("../models/Conversation");

let conversationId;

beforeAll(async () => {
  await mongoose.connect("mongodb://localhost:27017/edusphere_test", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
});

afterAll(async () => {
  await mongoose.connection.db.dropDatabase();
  await mongoose.connection.close();
});

describe("Message API", () => {
  const studentId = "student123";
  const tutorId = "tutor456";

  it("should start a new conversation", async () => {
    const res = await request(app)
      .post("/api/messages/start")
      .send({ user1: studentId, user2: tutorId });
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty("_id");
    conversationId = res.body._id;
  });

  it("should send a message", async () => {
    const res = await request(app)
      .post("/api/messages/send")
      .send({ conversationId, senderId: studentId, content: "Hello Tutor!" });
    expect(res.statusCode).toBe(201);
    expect(res.body.content).toBe("Hello Tutor!");
  });

  it("should retrieve message history", async () => {
    const res = await request(app).get(`/api/messages/${conversationId}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });
});
